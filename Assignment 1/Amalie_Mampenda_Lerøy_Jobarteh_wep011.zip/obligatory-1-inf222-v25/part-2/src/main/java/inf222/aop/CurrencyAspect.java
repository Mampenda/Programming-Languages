package inf222.aop;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
// import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.reflect.Field;

// import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
// import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
// import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class CurrencyAspect {
    // Define time format to show how long each inquiry takes
    private static final DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss.SSSSSSSS").withZone(ZoneId.systemDefault());

    // Define conversion rates to NOK
    private static final Map<String, Double> conversionRates = new HashMap<>();
    static {
        conversionRates.put("GBP", 14.0); // Rate: 1 GBP = 14   NOK
        conversionRates.put("USD", 11.0); // Rate: 1 USD = 11   NOK
        conversionRates.put("DKK", 1.5);  // Rate: 1 DKK = 1.5  NOK
        conversionRates.put("JPY", 0.07); // Rate: 1 JPY = 0.07 NOK
    }

    // Pointcut to match field accesses in the Arithmetics class
    @Pointcut("get(double inf222.aop.Arithmetics.*)")
    public void fieldAccess() {}

    // Pointcut to match field modifications in the Arithmetics class
    @Pointcut("set(double inf222.aop.Arithmetics.*)")
    public void fieldModification() {}

    // // Before executing any method in the Arithmetics class, with any number of arguments, do the following
    // @Before("execution(* inf222.aop.Arithmetics.*(..))")
    // public void beforeControllerAdvice(JoinPoint joinPoint) {
    //     System.out.println("\nRequest to " + joinPoint.getSignature().getName() + " with arguments " + formatArguments(joinPoint.getArgs())
    //                     + " started at " + timeFormat.format(Instant.now()));
    // }

    // Around advice to handle field accesses and convert value to NOK
    @Around("fieldAccess()")
    public Object aroundFieldAccess(ProceedingJoinPoint joinPoint) throws Throwable {
        String fieldName = joinPoint.getSignature().getName();
        Object target = joinPoint.getTarget();
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        double originalValue = (double) field.get(target);
        double nokValue = convertToNOK(fieldName, originalValue);
        System.out.println("\nAccessing field: " + fieldName + " = " + originalValue + " at time: " + timeFormat.format(Instant.now())
                        + "\nConverted value: " + fieldName + " = " + originalValue + " <=> NOK = " + nokValue);
        return nokValue;
    }

    // Around advice to handle field modifications and convert value back to original currency
    @Around("fieldModification() && !cflow(execution(inf222.aop.Arithmetics.new(..)))")
    public void aroundFieldModification(ProceedingJoinPoint joinPoint) throws Throwable {
        String fieldName = joinPoint.getSignature().getName();
        Object target = joinPoint.getTarget();
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);

        // Get new value passed to setter
        Object[] args = joinPoint.getArgs();
        if (args == null || args.length == 0) {
            return;
        }

        // Convert the new value back to original currency
        double newValue = (double) args[0];
        double convertedBackValue = convertFromNOK(fieldName, newValue);
        System.out.println("\nModifying field: " + fieldName + "\nConverted from NOK = " + newValue + " <=> " + fieldName + " = " + convertedBackValue);

        // Check for negative values
        if (convertedBackValue < 0) {
            throw new IllegalArgumentException("Currency value cannot be negative");
        }

        // Proceed with the modified value in original currency
        joinPoint.proceed(new Object[] {convertedBackValue});
    }

    // Method to convert field value to NOK based on the field name
    private double convertToNOK(String fieldName, double fieldValue) {
        Pattern pattern = Pattern.compile(".*_(GBP|USD|JPY|DKK)$");
        Matcher matcher = pattern.matcher(fieldName);
        if (matcher.matches()) {
            String currency = matcher.group(1);
            Double rate = conversionRates.get(currency);
            if (rate != null) {
                return fieldValue * rate; // Return the new value if conversion rate is found
            }
        }
        return fieldValue; // Return the original value if no conversion rate is found
    }

    // Method to convert field value from NOK to original currency based on the field name
    private double convertFromNOK(String fieldName, double fieldValue) {
        Pattern pattern = Pattern.compile(".*_(GBP|USD|JPY|DKK)$");
        Matcher matcher = pattern.matcher(fieldName);
        if (matcher.matches()) {
            String currency = matcher.group(1);
            Double rate = conversionRates.get(currency);
            if (rate != null) {
                return fieldValue / rate; // Return the new value if conversion rate is found
            }
        }
        return fieldValue; // Return the original value if no conversion rate is found
    }

    // // After executing any method in the Arithmetics class, with any number of arguments, do the following
    // @After("execution(* inf222.aop.Arithmetics.*(..))")
    // public void afterControllerAdvice(JoinPoint joinPoint) {
    //     System.out.println("\nRequest to " + joinPoint.getSignature().getName() + " with arguments " + formatArguments(joinPoint.getArgs())
    //                     + " finished at " + timeFormat.format(Instant.now())); 
    // }

    // // Method to better format arguments
    // private String formatArguments(Object[] args) {

    //     // Check if the arguments are null or empty
    //     if (args == null || args.length == 0) {
    //         return "[]";
    //     }

    //     StringBuilder sb = new StringBuilder("["); // String builder is more efficient than concatenating strings

    //     // Iterate over the arguments array
    //     for (int i = 0; i < args.length; i++) {

    //         // Add a comma and space between them, except for the first argument
    //         if (i > 0) {
    //             sb.append(", ");
    //         }

    //         // Check if the current argument is not null. If it's an array, append the class name and the string representation of the array
    //         if (args[i] != null) {
    //             if (args[i].getClass().isArray()) {
    //                 sb.append(args[i].getClass().getSimpleName()).append(": ").append(Arrays.deepToString((Object[]) args[i]));
    //             } else {
    //                 // Append only class name and string representation of the argument
    //                 sb.append(args[i].getClass().getSimpleName()).append(": ").append(args[i].toString());
    //             }
    //         } else {
    //             sb.append("null"); // Append "null" if the argument is null
    //         }
    //     }
    //     sb.append("]");
    //     return sb.toString();
    // }

}