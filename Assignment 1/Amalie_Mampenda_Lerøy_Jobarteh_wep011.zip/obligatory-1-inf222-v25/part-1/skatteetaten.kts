// Abstract class representing a taxpayer with an ID
abstract class Taxpayer(val id: String){
    override fun toString(): String{
        return id
    }
}
// Employee class that extends  (inherits from) Taxpayer
class Employee(id: String, val salary: Double) : Taxpayer(id)

// Business class that extends  (inherits from) Taxpayer
class Business(id: String, val revenue: Double, val expenses: Double) : Taxpayer(id)

// Freelancer class that extends  (inherits from) Taxpayer
class Freelancer(id: String, val projects: List<Double>) : Taxpayer(id)

// Interface representing a tax rule for a specific type of taxpayer
fun interface TaxRule< in T : Taxpayer> {
    fun calculateTax(taxpayer: T): Double
}

// Class representing a tax office that manages taxpayers and their tax rules
class TaxOffice<T : Taxpayer> {

    // List of registered taxpayers and assigned tax rules
    private val taxpayers = mutableListOf<T>()
    private val taxRules = mutableListOf<TaxRule<T>>()

    // Register a taxpayer
    fun registerTaxpayer(taxpayer: T) { 
        taxpayers.add(taxpayer)
    }

    // Assign a tax rule
    fun assignTaxRule(taxRule: TaxRule<T>) {
        taxRules.add(taxRule)
    }

    // Calculate taxes for all registered taxpayers
    fun calculateTaxes(): Map<String, Double> {
        return taxpayers.associate { taxpayer ->
            val totalTax = taxRules.sumOf { it.calculateTax(taxpayer) }
            taxpayer.id to totalTax
        }
    }
}

class Skatteetaten {

    // Mutable map of tax offices
    private val offices = mutableMapOf<String, TaxOffice<out Taxpayer>>()

    // Add a tax office
    fun addOffice(name: String, office: TaxOffice<out Taxpayer>) {
        offices[name] = office
    }

    // Get all tax offices
    fun getOffices(): Map<String, TaxOffice<out Taxpayer>> {
        return offices
    }
}

fun main(){
    // Taxpayers
    val employee1 = Employee("E001", 500_000.0)
    val employee2 = Employee("E002", 600_000.0)

    val business1 = Business("B001", 1_000_000.0, 400_000.0)
    val business2 = Business("B002", 2_000_000.0, 1_200_000.0)

    val freelancer1 = Freelancer("F001", listOf(50_000.0, 80_000.0))
    val freelancer2 = Freelancer("F002", listOf(100_000.0, 200_000.0))

    // Tax Rules

    // flat fee of 10 NOK for any income earner
    val generalTaxRule = TaxRule<Taxpayer> { _ -> 10.0 } 

    // 30% tax on salary
    val employeeTaxRule = TaxRule<Employee> { taxpayer -> taxpayer.salary * 0.3 }
    
    // 20% tax on profit
    val businessTaxRule = TaxRule<Business> {taxpayer ->  (taxpayer.revenue - taxpayer.expenses) * 0.2  } 

    // 25% tax on total project income
    val freelancerTaxRule = TaxRule<Freelancer> { taxpayer -> taxpayer.projects.sum() * 0.25 } 
    
    // Tax Offices
    val employeeOffice = TaxOffice<Employee>().apply {
        registerTaxpayer(employee1)
        registerTaxpayer(employee2)
        assignTaxRule(employeeTaxRule)
        assignTaxRule(generalTaxRule)
    }
    
    val businessOffice = TaxOffice<Business>().apply {
        registerTaxpayer(business1)
        registerTaxpayer(business2)
        assignTaxRule(businessTaxRule)
        assignTaxRule(generalTaxRule)
    }
    
    val freelancerOffice = TaxOffice<Freelancer>().apply {
        registerTaxpayer(freelancer1)
        registerTaxpayer(freelancer2)
        assignTaxRule(freelancerTaxRule)
        assignTaxRule(generalTaxRule)
    }

    // Skatteetaten
    val skatteetaten = Skatteetaten().apply {
        addOffice("Employees", employeeOffice)
        addOffice("Businesses", businessOffice)
        addOffice("Freelancers", freelancerOffice)
    }

    // Calculate Taxes
    for (office in skatteetaten.getOffices()){
        println("${office.key} taxes: ${office.value.calculateTaxes()}")
    }
}

main()

// Expected output:

// Employees taxes: {E001=150010.0, E002=180010.0}
// Businesses taxes: {B001=120010.0, B002=160010.0}
// Freelancers taxes: {F001=32510.0, F002=75010.0}
