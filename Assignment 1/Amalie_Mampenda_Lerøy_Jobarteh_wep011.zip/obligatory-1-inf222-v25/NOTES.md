# Process

## Part 1

Tried adding the following code:

```kotlin
// Class representing a tax office that manages taxpayers and their tax rules
class TaxOffice<T : Taxpayer> {

    // List of registered taxpayers and assigned tax rules
    private val taxpayers = mutableListOf<T>()
    private val taxRules = mutableListOf<TaxRule<T>>()

    // Register a taxpayer
    fun registerTaxpayer(taxpayer: T) {
        taxpayers.add(taxpayer)
    }

    // Assign a tax rule
    fun assignTaxRule(taxRule: TaxRule<T>) {
        taxRules.add(taxRule)
    }

    // Calculate taxes for all registered taxpayers
    fun calculateTaxes(): Map<String, Double> {
        return taxpayers.associate { taxpayer ->
            val totalTax = taxRules.sumOf { it.calculateTax(taxpayer) }
            taxpayer.id to totalTax
        }
    }
}

class Skatteetaten {

    // Mutable map of tax offices
    private val offices = mutableMapOf<String, TaxOffice<out Taxpayer>>()

    // Add a tax office
    fun addOffice(name: String, office: TaxOffice<out Taxpayer>) {
        offices[name] = office
    }

    // Get all tax offices
    fun getOffices(): Map<String, TaxOffice<out Taxpayer>> {
        return offices
    }
}
```

But got this error:

```bash
amali@MampendaPC MINGW64 ~/VSCodeProjects/INF222/Assignment 1/obligatory-1-inf222-v25/part-1 (main)
$ kotlinc -script skatteetaten.kts
skatteetaten.kts:93:23: error: argument type mismatch: actual type is 'TaxRule<Taxpayer>', but 'TaxRule<Employee>' was expected.
        assignTaxRule(generalTaxRule)
                      ^
skatteetaten.kts:100:23: error: argument type mismatch: actual type is 'TaxRule<Taxpayer>', but 'TaxRule<Business>' was expected.
        assignTaxRule(generalTaxRule)
                      ^
skatteetaten.kts:107:23: error: argument type mismatch: actual type is 'TaxRule<Taxpayer>', but 'TaxRule<Freelancer>' was expected.
        assignTaxRule(generalTaxRule)
                      ^
```

Meaning the `generalTaxRule` is of type `TaxRule<Taxpayer>`, but the `assignTaxRule` method expects a `TaxRule` of the specific taxpayer type (e.g., `TaxRule<Employee>`, `TaxRule<Business>`, `TaxRule<Freelancer>`).

In other words, there's an error related to type variance!

More specifically, the error occurs on this line:

```kotlin
assignTaxRule(generalTaxRule) // Error here for Employee Office
assignTaxRule(generalTaxRule) // Error here for Business Office
assignTaxRule(generalTaxRule) // Error here for Freelancer Office
```

`generalTaxRule` is of type `TaxRule<Taxpayer>`, but `employeeOffice` is a `TaxOffice<Employee>`, which expects a `TaxRule<Employee>`.

These types are not compatible because `TaxRule<Taxpayer>` cannot be directly assigned to `TaxRule<Employee>`. The same problem applies for the `businessOffice` and `freelancerOffice` assignments.

Given that `main()` is not supposed to be modified, I had to to use covariance to handle the type mismatch.

Covariance allows a more generic type (`Taxpayer`) where a specific type (`Employee`, `Business`, `Freelancer`) is expected, like when a vending machine is contracted to give out a snack, it can provide a candybar.

So, I tried to make the interface `TaxRule` covariant by using the `out` keyword, which allow a `TaxRule<Taxpayer>` where a `TaxRule<Employee>`, `TaxRule<Business>`, or `TaxRule<Freelancer>` is expected.

```kotlin
fun interface TaxRule< out T : Taxpayer> {
    fun calculateTax(taxpayer: T): Double
}
```

But I still got the same three errors, in addition to this new one:

```bash
skatteetaten.kts:18:32: error: type parameter 'T' is declared as 'out' but occurs in 'in' position in type 'T'.
    fun calculateTax(taxpayer: T): Double
```

So adding the keyword `out` makes the `T` in the interface covariant, meaning it can only be used in **output positions**. However, in this function:

```kotlin
fun calculateTax(taxpayer: T): Double
```

`taxpayer: T` is in an **input position** (i.e., function parameter), and covariant types (`out T`) cannot be used as function parameters.

Putting `out` in the interface, didn't work, so I tried making it contravariant (`in`) instead:

```kotlin
// Interface representing a tax rule for a specific type of taxpayer
fun interface TaxRule< in T : Taxpayer> {
    fun calculateTax(taxpayer: T): Double
}
```

Which gave the desired output:

```bash
$ kotlinc -script skatteetaten.kts
Employees taxes: {E001=150010.0, E002=180010.0}
Businesses taxes: {B001=120010.0, B002=160010.0}
Freelancers taxes: {F001=32510.0, F002=75010.0}
```

## Part 2.1

### Explanation for the AspectJ methods

#### Around Advice for Field Access:

The aroundFieldAccess method intercepts field accesses and converts the values to NOK. It uses the ProceedingJoinPoint to proceed with the original access and then logs the converted value.

#### Around Advice for Field Modification:

The aroundFieldModification method intercepts field modifications and converts the values back to their original currencies after modification. It uses the ProceedingJoinPoint to proceed with the original modification and then converts the value back to the original currency.

#### Conversion Methods:

The convertToNOK method converts field values to NOK based on the field name.
The convertFromNOK method converts field values from NOK to the original currency based on the field name.

#### Constructor Exclusion:

The aroundFieldModification method excludes field modifications inside the constructor using the cflow(execution(inf222.aop.Arithmetics.new(..))) pointcut.

(I spent 2 days wondering why I got the wrong output before I read the rest of the assignment... Next time: READ THE WHOLE ASSIGNMENT TEXT BEFORE STARTING ANYTHING)

## Part 2.2

To handle field modifications correctly and ensure that the value is converted back to its original currency from NOK, I need to modify the `aroundFieldModification` advice. This advice should intercept field modifications, convert the value to NOK for the modification, and then convert it back to the original currency after the modification.

### Explanation

#### Convert to NOK:

The original value is converted to NOK before the modification.
Proceed with NOK Value:

The `joinPoint.proceed(new Object[] {nokValue})` method is used to proceed with the modification using the NOK value.

#### Convert Back to Original Currency:

After the modification, the new value is converted back to the original currency using the `convertFromNOK` method.

#### Set the Converted Back Value:

The converted back value is set to the field to ensure it holds the correct value in the original currency.

### Problems

Got stuck on why this code was getting the right values when logged:

```java
package inf222.aop;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.reflect.Field;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class CurrencyAspect {
    // Define time format to show how long each inquiry takes
    private static final DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss.SSSSSSSS").withZone(ZoneId.systemDefault());

    // Define conversion rates to NOK
    private static final Map<String, Double> conversionRates = new HashMap<>();
    static {
        conversionRates.put("GBP", 14.0); // Rate: 1 GBP = 14   NOK
        conversionRates.put("USD", 11.0); // Rate: 1 USD = 11   NOK
        conversionRates.put("DKK", 1.5);  // Rate: 1 DKK = 1.5  NOK
        conversionRates.put("JPY", 0.07); // Rate: 1 JPY = 0.07 NOK
    }

    // Pointcut to match field accesses in the Arithmetics class
    @Pointcut("get(double inf222.aop.Arithmetics.*)")
    public void fieldAccess() {}

    // Pointcut to match field modifications in the Arithmetics class
    @Pointcut("set(double inf222.aop.Arithmetics.*)")
    public void fieldModification() {}

    // Before executing any method in the Arithmetics class, with any number of arguments, do the following
    @Before("execution(* inf222.aop.Arithmetics.*(..))")
    public void beforeControllerAdvice(JoinPoint joinPoint) {
        System.out.println("\nRequest to " + joinPoint.getSignature().getName() + " with arguments " + formatArguments(joinPoint.getArgs())
                        + " started at " + timeFormat.format(Instant.now()));
    }

    // Around advice to handle field accesses and convert value to NOK
    @Around("fieldAccess()")
    public Object aroundFieldAccess(ProceedingJoinPoint joinPoint) throws Throwable {
        String fieldName = joinPoint.getSignature().getName();
        Object target = joinPoint.getTarget();
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        double originalValue = (double) field.get(target);
        double nokValue = convertToNOK(fieldName, originalValue);
        System.out.println("\nAccessing field: " + fieldName + " = " + originalValue + " at time: " + timeFormat.format(Instant.now())
                        + "\nConverted value: " + fieldName + " = " + originalValue + " <=> NOK = " + nokValue);
        return joinPoint.proceed();
    }

    // Around advice to handle field modifications and convert value back to original currency
    @Around("fieldModification() && !cflow(execution(inf222.aop.Arithmetics.new(..)))")
    public void aroundFieldModification(ProceedingJoinPoint joinPoint) throws Throwable {
        String fieldName = joinPoint.getSignature().getName();
        Object target = joinPoint.getTarget();
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);

        // Get the original value of field and convert it to NOK
        double originalValue = (double) field.get(target);
        double nokValue = convertToNOK(fieldName, originalValue);
        System.out.println("\nOriginal value before modification: " + originalValue + "\nConverted to NOK: " + nokValue);

        // Proceed with the modification in NOK
        // joinPoint.proceed(new Object[] {nokValue});

        // Proceed with the modification in NOK (we pass the NOK value to modify)
        Object[] args = joinPoint.getArgs();
        if (args != null && args.length > 0) {
            args[0] = nokValue; // Modify the argument passed to the method
        }
        joinPoint.proceed(args); // Proceed with modified argument


        // After modification, retrieve the nev value (NOK), and convert back to the original currency
        double newValue = (double) field.get(target);
        double convertedBackValue = convertFromNOK(fieldName, newValue);
        System.out.println("New value after modification: " + newValue + "\nConverted back to original currency: " + convertedBackValue);

        // Check for negative values
        if (convertedBackValue < 0) {
            throw new IllegalArgumentException("Currency value cannot be negative");
        }

        // Set the final value back to the field
        field.set(target, convertedBackValue);
    }

    // Method to convert field value to NOK based on the field name
    private double convertToNOK(String fieldName, double fieldValue) {
        Pattern pattern = Pattern.compile(".*_(GBP|USD|JPY|DKK)$");
        Matcher matcher = pattern.matcher(fieldName);
        if (matcher.matches()) {
            String currency = matcher.group(1);
            Double rate = conversionRates.get(currency);
            if (rate != null) {
                return fieldValue * rate;
            }
        }
        return fieldValue; // Return the original value if no conversion rate is found
    }

    // Method to convert field value from NOK to original currency based on the field name
    private double convertFromNOK(String fieldName, double fieldValue) {
        Pattern pattern = Pattern.compile(".*_(GBP|USD|JPY|DKK)$");
        Matcher matcher = pattern.matcher(fieldName);
        if (matcher.matches()) {
            String currency = matcher.group(1);
            Double rate = conversionRates.get(currency);
            if (rate != null) {
                return fieldValue / rate;
            }
        }
        return fieldValue; // Return the original value if no conversion rate is found
    }

    // After executing any method in the Arithmetics class, with any number of arguments, do the following
    @After("execution(* inf222.aop.Arithmetics.*(..))")
    public void afterControllerAdvice(JoinPoint joinPoint) {
        System.out.println("\nRequest to " + joinPoint.getSignature().getName() + " with arguments " + formatArguments(joinPoint.getArgs())
                        + " finished at " + timeFormat.format(Instant.now()));
    }

    // Method to better format arguments
    private String formatArguments(Object[] args) {

        // Check if the arguments are null or empty
        if (args == null || args.length == 0) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder("["); // String builder is more efficient than concatenating strings

        // Iterate over the arguments array
        for (int i = 0; i < args.length; i++) {

            // Add a comma and space between them, except for the first argument
            if (i > 0) {
                sb.append(", ");
            }

            // Check if the current argument is not null. If it's an array, append the class name and the string representation of the array
            if (args[i] != null) {
                if (args[i].getClass().isArray()) {
                    sb.append(args[i].getClass().getSimpleName()).append(": ").append(Arrays.deepToString((Object[]) args[i]));
                } else {
                    // Append only class name and string representation of the argument
                    sb.append(args[i].getClass().getSimpleName()).append(": ").append(args[i].toString());
                }
            } else {
                sb.append("null"); // Append "null" if the argument is null
            }
        }
        sb.append("]");
        return sb.toString();
    }

}
```

```bash
Request to main with arguments [String[]: []] started at 11:24:51.62815600

Request to runExample with arguments [] started at 11:24:51.65116090

Initial Values:

Request to printValues with arguments [] started at 11:24:51.65116090

Accessing field: a_GBP = 5.0 at time: 11:24:51.65816150
Converted value: a_GBP = 5.0 <=> NOK = 70.0
a_GBP: 70.0

Accessing field: b_USD = 3.0 at time: 11:24:51.68417990
Converted value: b_USD = 3.0 <=> NOK = 33.0
b_USD: 33.0

Accessing field: c_NOK = 100.0 at time: 11:24:51.68518080
Converted value: c_NOK = 100.0 <=> NOK = 100.0
c_NOK: 100.0

Accessing field: d_JPY = 200.0 at time: 11:24:51.68669680
Converted value: d_JPY = 200.0 <=> NOK = 14.000000000000002
d_JPY: 14.000000000000002

Accessing field: e_DKK = 50.0 at time: 11:24:51.68871560
Converted value: e_DKK = 50.0 <=> NOK = 75.0
e_DKK: 75.0

Request to printValues with arguments [] finished at 11:24:51.68971960

Accessing field: a_GBP = 5.0 at time: 11:24:51.69172150
Converted value: a_GBP = 5.0 <=> NOK = 70.0

Accessing field: b_USD = 3.0 at time: 11:24:51.69172150
Converted value: b_USD = 3.0 <=> NOK = 33.0

Original value before modification: 5.0
Converted to NOK: 70.0
New value after modification: 70.0
Converted back to original currency: 5.0

Accessing field: c_NOK = 100.0 at time: 11:24:51.70171510
Converted value: c_NOK = 100.0 <=> NOK = 100.0

Original value before modification: 100.0
Converted to NOK: 100.0
New value after modification: 100.0
Converted back to original currency: 100.0

Accessing field: d_JPY = 200.0 at time: 11:24:51.70271420
Converted value: d_JPY = 200.0 <=> NOK = 14.000000000000002

Original value before modification: 200.0
Converted to NOK: 14.000000000000002
New value after modification: 14.000000000000002
Converted back to original currency: 200.0

Accessing field: e_DKK = 50.0 at time: 11:24:51.70471500
Converted value: e_DKK = 50.0 <=> NOK = 75.0

Original value before modification: 50.0
Converted to NOK: 75.0
New value after modification: 75.0
Converted back to original currency: 50.0

Accessing field: b_USD = 3.0 at time: 11:24:51.70571250
Converted value: b_USD = 3.0 <=> NOK = 33.0

Original value before modification: 3.0
Converted to NOK: 33.0
New value after modification: 33.0
Converted back to original currency: 3.0

After First Operations:

Request to printValues with arguments [] started at 11:24:51.70671390

Accessing field: a_GBP = 5.0 at time: 11:24:51.70772060
Converted value: a_GBP = 5.0 <=> NOK = 70.0
a_GBP: 70.0

Accessing field: b_USD = 3.0 at time: 11:24:51.70772060
Converted value: b_USD = 3.0 <=> NOK = 33.0
b_USD: 33.0

Accessing field: c_NOK = 100.0 at time: 11:24:51.70872180
Converted value: c_NOK = 100.0 <=> NOK = 100.0
c_NOK: 100.0

Accessing field: d_JPY = 200.0 at time: 11:24:51.70972230
Converted value: d_JPY = 200.0 <=> NOK = 14.000000000000002
d_JPY: 14.000000000000002

Accessing field: e_DKK = 50.0 at time: 11:24:51.70972230
Converted value: e_DKK = 50.0 <=> NOK = 75.0
e_DKK: 75.0

Request to printValues with arguments [] finished at 11:24:51.71071910

Accessing field: a_GBP = 5.0 at time: 11:24:51.71271860
Converted value: a_GBP = 5.0 <=> NOK = 70.0

Accessing field: b_USD = 3.0 at time: 11:24:51.71371770
Converted value: b_USD = 3.0 <=> NOK = 33.0

Accessing field: c_NOK = 100.0 at time: 11:24:51.71472200
Converted value: c_NOK = 100.0 <=> NOK = 100.0

Accessing field: d_JPY = 200.0 at time: 11:24:51.71571540
Converted value: d_JPY = 200.0 <=> NOK = 14.000000000000002

Accessing field: e_DKK = 50.0 at time: 11:24:51.71571540
Converted value: e_DKK = 50.0 <=> NOK = 75.0

Accessing field: a_GBP = 5.0 at time: 11:24:51.71675020
Converted value: a_GBP = 5.0 <=> NOK = 70.0

Accessing field: b_USD = 3.0 at time: 11:24:51.71871780
Converted value: b_USD = 3.0 <=> NOK = 33.0

Accessing field: c_NOK = 100.0 at time: 11:24:51.71971310
Converted value: c_NOK = 100.0 <=> NOK = 100.0

Accessing field: d_JPY = 200.0 at time: 11:24:51.72071440
Converted value: d_JPY = 200.0 <=> NOK = 14.000000000000002

Accessing field: e_DKK = 50.0 at time: 11:24:51.72071440
Converted value: e_DKK = 50.0 <=> NOK = 75.0

Accessing field: c_NOK = 100.0 at time: 11:24:51.72171650
Converted value: c_NOK = 100.0 <=> NOK = 100.0

Accessing field: a_GBP = 5.0 at time: 11:24:51.72171650
Converted value: a_GBP = 5.0 <=> NOK = 70.0

Computed Values:
Sum of all currencies: 292.0
Average value: 58.4
Product of all currencies: 2.4255000000000003E8
Difference (NOK - GBP): 30.0

Request to runExample with arguments [] finished at 11:24:51.72372010

Request to main with arguments [String[]: []] finished at 11:24:51.72372010
```

### Issues & Fixes

#### 1. Incorrect Return in `aroundFieldAccess`

**Issue**: aroundFieldAccess currently calls joinPoint.proceed() without modifying the returned value.
**Fix**: Instead of just proceeding, return the converted NOK value.

#### 2. Incorrect Modification Handling in `aroundFieldModification`

**Issue**:

- `joinPoint.proceed(args);` should be called with the converted original currency value, not the NOK value.
- `Setting args[0] = nokValue;` is incorrect because the argument should be converted back to the original currency.

**Fix**: Convert the new incoming value from NOK to the original currency before proceeding.

#### 3. Java's floating-point division

**Issue**: When converting back from NOK in `convertFromNOK()`, Java's floating-point division causes the result to have more decimal places than expected because of the division of a double.

**Fix**: Remove the extra logging, instead of trying to fix it using `round()` or `BigDecimal()`, etc., as it's not a part of the asignment.
